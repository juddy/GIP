<table width="250" cellspacing="0" cellpadding="3" bgcolor="#000066">
<tr>
<td><table width="100%" border="0" cellspacing="0" bgcolor="#FFFFFF">
<tr height=35>
<td bgcolor="#FFFFFF" align=left><h3>Table MAIN</h3></td>
</tr>
<tr height=20>
<td>
<table cellspacing=0 cellpadding=0 border=0>
<tr>
<td width=20>
&nbsp;
</td>
<td>
<li><a href="./main/enterNewMain.php">Enter New main</a></li>
<li><a href="./main/listMain.php">List All main</a></li>
<li><a href="./main/searchMainForm.php">Power Search main</a></li>
<li><a href="./main/listGridMain.php">CRUD Grid for main</a></li>
</td>
</tr>
</table>
</td>
</tr>
<tr height=20>
<td>&nbsp;</td>
</tr>
</table></td>
</tr>
</table>