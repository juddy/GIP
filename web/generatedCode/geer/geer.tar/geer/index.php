<? include_once("common/header.php"); ?>

<table cellspacing=10 cellpadding=9>
	<tr>
		<td>
			<? include_once("./index/indexMain.inc.php"); ?>
		</td>
	</tr>
</table>
<? include_once("common/footer.php"); ?>

