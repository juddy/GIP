<?php
include_once("../common/dbConnection.php");
include_once("../common/header.php");
?>
<h2>About Us</h2>



<?php
include_once("../common/footer.php");
?>